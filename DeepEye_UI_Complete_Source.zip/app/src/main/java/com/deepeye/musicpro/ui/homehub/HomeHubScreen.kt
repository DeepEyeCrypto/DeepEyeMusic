// Copyright (C) 2026 DeepEye
// SPDX-License-Identifier: GPL-3.0-or-later

package com.deepeye.musicpro.ui.homehub

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.repeatOnLifecycle
import com.deepeye.musicpro.ui.components.DynamicLabel
import com.deepeye.musicpro.ui.components.SecondaryLabel
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.deepeye.musicpro.ui.components.bouncyClickable
import coil3.compose.AsyncImage
import coil3.request.crossfade
import com.deepeye.musicpro.domain.model.home.HomeMusicItem
import com.deepeye.musicpro.domain.model.home.HomeVideoItem
import com.deepeye.musicpro.ui.components.ShimmerBox
import com.deepeye.musicpro.ui.youtube.SmartTubeVideoCard
import com.deepeye.musicpro.ui.components.premium.PremiumHeroCard
import com.deepeye.musicpro.ui.components.premium.SplitMediaHero
import com.deepeye.musicpro.ui.components.premium.DotMatrixClock
import com.deepeye.musicpro.ui.theme.GlassBorder
import com.deepeye.musicpro.ui.components.glassCard
import com.deepeye.musicpro.ui.components.hoverable
import com.deepeye.musicpro.ui.gamification.Top3LeaderboardCard


@Composable
fun HomeHubScreen(
    windowSizeClass: androidx.compose.material3.windowsizeclass.WindowSizeClass,
    onNavigateToVideo: (String) -> Unit,
    onNavigateToMusic: (String) -> Unit,
    onNavigateToLibrary: () -> Unit,
    onNavigateToChat: () -> Unit = {},
    onOpenV4A: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: HomeHubViewModel = hiltViewModel(),
    playerViewModel: com.deepeye.musicpro.ui.player.PlayerViewModel = hiltViewModel(),
    recommendationViewModel: com.deepeye.musicpro.ui.home.RecommendationViewModel = hiltViewModel(),
) {
    val feedState by viewModel.feedState.collectAsStateWithLifecycle()
    val recs by recommendationViewModel.recommendations.collectAsStateWithLifecycle()
    val isRecsLoading by recommendationViewModel.isRefreshing.collectAsStateWithLifecycle()
    val dspEngineState by viewModel.isDspAttached.collectAsStateWithLifecycle()
    val gamificationState by viewModel.gamificationState.collectAsStateWithLifecycle()
    val top3Users by viewModel.top3Users.collectAsStateWithLifecycle()

    val isExpanded = windowSizeClass.widthSizeClass == androidx.compose.material3.windowsizeclass.WindowWidthSizeClass.Expanded

    var showGamificationSheet by remember { mutableStateOf(false) }
    var showRankingSheet by remember { mutableStateOf(false) }

    if (showGamificationSheet) {
        @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { showGamificationSheet = false },
            containerColor = Color(0xFF1E1E1E)
        ) {
            com.deepeye.musicpro.ui.gamification.GamificationBottomSheet(
                streak = gamificationState.streak,
                rewardPoints = gamificationState.rewardPoints,
                unlockedBadges = gamificationState.unlockedBadges,
                lockedBadges = gamificationState.lockedBadges,
                onClaimReward = { showGamificationSheet = false }
            )
        }
    }

    if (showRankingSheet) {
        com.deepeye.musicpro.ui.ranking.RankingBottomSheet(
            rankingRepository = viewModel.rankingRepository,
            rankingEngine = viewModel.rankingEngine,
            onDismissRequest = { showRankingSheet = false }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent),
        contentAlignment = Alignment.TopCenter,
    ) {
        var achievementToShow by remember { mutableStateOf<com.deepeye.musicpro.domain.gamification.UserAchievement?>(null) }
        val context = androidx.compose.ui.platform.LocalContext.current
        
        LaunchedEffect(Unit) {
            viewModel.achievementEvents.collect { event ->
                // Find badge in state
                val badge = gamificationState.unlockedBadges.find { it.requirement == event.requirement }
                if (badge != null) {
                    achievementToShow = badge
                }
            }
        }

        achievementToShow?.let { badge ->
            com.deepeye.musicpro.ui.gamification.AchievementUnlockedPopup(
                badge = badge,
                onDismiss = { achievementToShow = null },
                onShare = {
                    achievementToShow = null
                    // MOCK Instagram share
                    android.widget.Toast.makeText(
                        context,
                        "Sharing to Instagram Stories...",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }

        LazyColumn(
            modifier =
            Modifier
                .fillMaxSize()
                .then(
                    if (isExpanded) Modifier.widthIn(max = 1200.dp) else Modifier,
                ),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            contentPadding = PaddingValues(
                start = if (isExpanded) 32.dp else 0.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 130.dp,
                end = if (isExpanded) 32.dp else 0.dp,
                bottom = 260.dp, // Increased from 200.dp to ensure no overlap with Dock & Mini-Player
            ),
        ) {
            item {
                val btcPrice by viewModel.btcPrice.collectAsStateWithLifecycle()
                HomeGreetingHeader(
                    btcPrice = btcPrice,
                    onNavigateToSettings = onNavigateToSettings,
                    onNavigateToChat = onNavigateToChat
                )
            }

            // 1b. Featured Premium Audio Hero Card (AEOS Premium Feature)
            val featuredMusic = feedState.featuredMusic
            if (featuredMusic != null) {
                item {
                    PremiumHeroCard(
                        title = featuredMusic.title,
                        subtitle = featuredMusic.artist,
                        imageUrl = featuredMusic.thumbnailUrl,
                        badge = "Featured Premium Audio",
                        onClick = {
                            viewModel.playMusic(featuredMusic)
                            onNavigateToMusic(featuredMusic.id)
                        },
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }

            // 3. Continue Listening rail (Phase 7)
            if (feedState.continueListening.isNotEmpty()) {
                item {
                    ContinueListeningRow(
                        items = feedState.continueListening,
                        onItemClick = { music ->
                            viewModel.playContinueListeningItem(music)
                            onNavigateToMusic(music.id)
                        },
                    )
                }
            }

            item {
                HorizontalDivider(
                    color = Color.White.copy(0.05f),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }

            // 5. Mood Chips (Phase 7)
            if (feedState.moodMixes.isNotEmpty()) {
                item {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    android.util.Log.d("HomeHubScreen", "Calling MoodChipsRow with ${feedState.moodMixes.size} moods")
                    MoodChipsRow(
                        moods = feedState.moodMixes,
                        onMoodClick = { mood -> 
                            android.widget.Toast.makeText(context, "Generating playlist for ${mood.label}...", android.widget.Toast.LENGTH_SHORT).show()
                            viewModel.onMoodClick(mood) 
                        },
                    )
                }
            } else {
                item {
                    android.util.Log.d("HomeHubScreen", "MoodMixes is empty!")
                }
            }

            // 5b. YouTube / Trending Rails
            if (feedState.trending.isNotEmpty()) {
                item {
                    HomeVideoRail(
                        title = if (feedState.hasAuth) "🌟 For You" else "🔥 Trending",
                        items = feedState.trending,
                        onClick = { 
                            android.util.Log.e("HomeHubScreen", "Trending clicked: ${it.id}")
                            viewModel.playVideo(it)
                            onNavigateToVideo(it.id) 
                        }
                    )
                }
            }

            if (feedState.shorts.isNotEmpty()) {
                item {
                    ShortsRail(
                        items = feedState.shorts,
                        onClick = { 
                            android.util.Log.e("HomeHubScreen", "Short clicked: ${it.id}")
                            viewModel.playVideo(it)
                            onNavigateToVideo(it.id) 
                        }
                    )
                }
            }

            if (feedState.supermix.isNotEmpty()) {
                item {
                    android.util.Log.e("HomeHubScreen", "RENDERING SUPERMIX: size=${feedState.supermix.size}")
                    HomeMusicRail(
                        title = "✨ My Supermix",
                        items = feedState.supermix,
                        onClick = { 
                            android.util.Log.e("HomeHubScreen", "Supermix clicked: ${it.id}")
                            viewModel.playMusic(it)
                            onNavigateToMusic(it.id) 
                        }
                    )
                }
            }

            if (feedState.discoverMix.isNotEmpty()) {
                item {
                    android.util.Log.e("HomeHubScreen", "RENDERING DISCOVER: size=${feedState.discoverMix.size}")
                    HomeMusicRail(
                        title = "🔭 Discover Mix",
                        items = feedState.discoverMix,
                        onClick = { 
                            android.util.Log.e("HomeHubScreen", "Discover clicked: ${it.id}")
                            viewModel.playMusic(it)
                            onNavigateToMusic(it.id) 
                        }
                    )
                }
            }

            if (feedState.becauseYouLikedMix.isNotEmpty() && feedState.becauseYouLikedArtist != null) {
                item {
                    HomeMusicRail(
                        title = "❤️ Because You Liked ${feedState.becauseYouLikedArtist}",
                        items = feedState.becauseYouLikedMix,
                        onClick = {
                            viewModel.playMusic(it)
                            onNavigateToMusic(it.id)
                        }
                    )
                }
            }

            if (feedState.newReleases.isNotEmpty()) {
                item {
                    HomeMusicRail(
                        title = "🆕 New Releases For You",
                        items = feedState.newReleases,
                        onClick = {
                            viewModel.playMusic(it)
                            onNavigateToMusic(it.id)
                        }
                    )
                }
            }

            if (feedState.quickPicks.isNotEmpty()) {
                item {
                    HomeMusicRail(
                        title = "🎵 Quick Picks",
                        items = feedState.quickPicks,
                        onClick = { 
                            android.util.Log.e("HomeHubScreen", "Music clicked: ${it.id}")
                            viewModel.playMusic(it)
                            onNavigateToMusic(it.id) 
                        }
                    )
                }
            }

            // Phase 4: AI Prompt Bar
            item {
                val isGenerating by viewModel.isAIGenerating.collectAsStateWithLifecycle()
                val context = androidx.compose.ui.platform.LocalContext.current
                AIPromptBar(
                    isGenerating = isGenerating,
                    onSubmitPrompt = { prompt ->
                        android.widget.Toast.makeText(context, "AI is curating based on: $prompt", android.widget.Toast.LENGTH_SHORT).show()
                        viewModel.onAIPromptSubmitted(prompt)
                    }
                )
            }

            // 6. DSP Quick Panel (Phase 7)
            item {
                DspQuickPanel(
                    activePresetName = feedState.activeDspPreset,
                    isEngineAttached = dspEngineState == com.deepeye.musicpro.dsp.model.EngineState.ATTACHED ||
                        dspEngineState == com.deepeye.musicpro.dsp.model.EngineState.PROCESSING,
                    onOpenDsp = onOpenV4A,
                )
            }

            // 7. Local Library Resume (Phase 7)
            if (feedState.localResume.isNotEmpty()) {
                item {
                    LocalResumeRail(
                        items = feedState.localResume,
                        onItemClick = { music ->
                            viewModel.playLocalResume(music)
                            onNavigateToMusic(music.id)
                        },
                    )
                }
            }

            item {
                HorizontalDivider(
                    color = Color.White.copy(0.05f),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }

            // 8. Dynamic Recommendation Rows
            if (isRecsLoading && recs == null) {
                item { HomeRailShimmer(title = "Loading Recommendations...") }
                item { HomeRailShimmer(title = "") }
                item { HomeRailShimmer(title = "") }
            }

            recs?.let { result ->
                // Because you listened
                items(result.becauseYouListened) { row ->
                    com.deepeye.musicpro.ui.home.RecommendationRowUI(row, windowSizeClass) { video ->
                        playRecMusic(video, row.items, playerViewModel, onNavigateToMusic)
                    }
                }

                // Perfect for right now
                item {
                    com.deepeye.musicpro.ui.home.RecommendationRowUI(
                        result.perfectForNow,
                        windowSizeClass,
                        isHighlighted = true
                    ) { video ->
                        playRecMusic(video, result.perfectForNow.items, playerViewModel, onNavigateToMusic)
                    }
                }

                // Favorite artists
                items(result.favoriteArtists) { row ->
                    com.deepeye.musicpro.ui.home.RecommendationRowUI(row, windowSizeClass) { video ->
                        playRecMusic(video, row.items, playerViewModel, onNavigateToMusic)
                    }
                }

                // Trending
                item {
                    com.deepeye.musicpro.ui.home.RecommendationRowUI(result.trending, windowSizeClass) { video ->
                        playRecMusic(video, result.trending.items, playerViewModel, onNavigateToMusic)
                    }
                }

                // Genre dives
                items(result.genreDive) { row ->
                    com.deepeye.musicpro.ui.home.RecommendationRowUI(row, windowSizeClass) { video ->
                        playRecMusic(video, row.items, playerViewModel, onNavigateToMusic)
                    }
                }

                // Hidden gems
                item {
                    com.deepeye.musicpro.ui.home.RecommendationRowUI(
                        result.hiddenGems,
                        windowSizeClass,
                        isHighlighted = true
                    ) { video ->
                        playRecMusic(video, result.hiddenGems.items, playerViewModel, onNavigateToMusic)
                    }
                }
            }

            // 9. Offline fallback
            if (feedState.isOffline && !feedState.isLoading) {
                item {
                    OfflineFallbackCard(
                        onRetry = viewModel::loadFeed,
                    )
                }
            }
        } // Close LazyColumn here

        // Fluid Menu for Gamification (Upper Right)
        FluidMenu(
            items = listOf(
                FluidMenuItem(
                    icon = Icons.Default.Star,
                    tint = androidx.compose.ui.graphics.Color(0xFFFFD700),
                    onClick = { showGamificationSheet = true }
                ),
                FluidMenuItem(
                    icon = Icons.Default.Person,
                    tint = androidx.compose.ui.graphics.Color(0xFF00E5FF),
                    onClick = { showRankingSheet = true }
                ),
                FluidMenuItem(
                    icon = Icons.Default.Settings,
                    tint = androidx.compose.ui.graphics.Color.White,
                    onClick = onNavigateToSettings
                )
            ),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 16.dp, end = 16.dp)
        )
    }
}

@Composable
private fun HomeGreetingHeader(
    btcPrice: String,
    onNavigateToSettings: () -> Unit,
    onNavigateToChat: () -> Unit = {}
) {
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .padding(bottom = 8.dp)
                .wrapContentWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color.Black.copy(alpha = 0.4f)) // Premium dark pill
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clickable { onNavigateToChat() },
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(
                    imageVector = androidx.compose.material.icons.Icons.Default.Lock,
                    contentDescription = "Secure Chat",
                    tint = Color(0xFF7B3FE4),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = Color(0xFFFFD700))) { // Gold for Bitcoin icon
                            append("₿ ")
                        }
                        withStyle(SpanStyle(color = Color(0xFF00E676))) { // Neon Green for price
                            append(btcPrice.replace("₿ ", ""))
                        }
                    },
                    style = MaterialTheme.typography.titleMedium, // Much smaller, professional
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun HomeVideoRail(
    title: String,
    items: List<HomeVideoItem>,
    onClick: (HomeVideoItem) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            title,
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
        ) {
            items(items.size, key = { index -> "$index-${items[index].id}" }) { index ->
                val video = items[index]
                SmartTubeVideoCard(
                    video = video,
                    onClick = { onClick(video) },
                    modifier = Modifier.width(300.dp),
                )
            }
        }
    }
}

@Composable
private fun ShortsRail(
    items: List<HomeVideoItem>,
    onClick: (HomeVideoItem) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "📱 Shorts",
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFFE0E0E0),
            fontWeight = FontWeight.Bold,
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
        ) {
            items(items.size, key = { index -> "$index-${items[index].id}" }) { index ->
                val short = items[index]
                SmartTubeVideoCard(
                    video = short,
                    onClick = { onClick(short) },
                    modifier = Modifier.width(200.dp), // Narrower for shorts
                )
            }
        }
    }
}

@Composable
private fun HomeMusicRail(
    title: String,
    items: List<HomeMusicItem>,
    onClick: (HomeMusicItem) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            title,
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFFE0E0E0),
            fontWeight = FontWeight.Bold,
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(horizontal = 24.dp),
        ) {
            items(items, key = { it.id }) { music ->
                Box(
                    modifier =
                    Modifier
                        .width(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.05f)) // Smoother glass effect
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                        .bouncyClickable(
                            downScale = 0.95f,
                            onClick = { onClick(music) }
                        )
                        .padding(8.dp),
                ) {
                    Column {
                        Box(
                            modifier =
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(12.dp)),
                        ) {
                            AsyncImage(
                                model = coil3.request.ImageRequest.Builder(androidx.compose.ui.platform.LocalContext.current)
                                    .data(music.thumbnailUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = music.title,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = music.title,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = music.artist,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.LightGray.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeRailShimmer(title: String) {
    Column(Modifier.padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, modifier = Modifier.padding(horizontal = 20.dp), color = Color.White)
        Row(Modifier.padding(horizontal = 20.dp)) {
            repeat(3) {
                ShimmerBox(Modifier.size(140.dp))
                Spacer(Modifier.width(12.dp))
            }
        }
    }
}

@Composable
private fun OfflineFallbackCard(onRetry: () -> Unit) {
    Card(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors =
        CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                Icons.Rounded.WifiOff,
                contentDescription = null,
                tint = Color(0xFF9E9E9E),
                modifier = Modifier.size(48.dp),
            )
            Text(
                "Offline Mode",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFE0E0E0),
            )
            Text(
                "YouTube content unavailable.\nLocal library still works!",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF9E9E9E),
                textAlign = TextAlign.Center,
            )
            Button(
                onClick = onRetry,
                colors =
                ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF7B3FE4),
                ),
            ) {
                Text("Retry")
            }
        }
    }
}

private fun playRecMusic(
    video: com.deepeye.musicpro.domain.recommendation.VideoItem,
    contextList: List<com.deepeye.musicpro.domain.recommendation.VideoItem>,
    playerViewModel: com.deepeye.musicpro.ui.player.PlayerViewModel,
    onNavigateToMusic: (String) -> Unit,
) {
    val mediaItems =
        contextList.map {
            com.deepeye.musicpro.domain.model.MediaItem.Remote(
                id = it.videoId,
                title = it.title,
                artist = it.artist,
                artworkUri = android.net.Uri.parse("https://i.ytimg.com/vi/${it.videoId}/hqdefault.jpg"),
                duration = 180000L, // Mock duration
                isVideo = false,
            )
        }
    val index = contextList.indexOfFirst { it.videoId == video.videoId }
    playerViewModel.setQueue(mediaItems, if (index >= 0) index else 0)
    onNavigateToMusic(video.videoId)
}
